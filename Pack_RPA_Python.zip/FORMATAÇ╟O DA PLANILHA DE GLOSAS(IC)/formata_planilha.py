from datetime import datetime
from operator import index
from statistics import mode
import pandas as pd
from functools import partial
from tqdm import tqdm


#Contando a quantidade de linhas do arquivo
arq = 'audita_glosa_auditar_item_dc362200_73728acb.csv'
buffer=2**16
with open(arq) as f:
    total =  (sum(x.count('\n') for x in iter(partial(f.read,buffer), '')))
    cs = int(total / 100)
    print (cs)




df = pd.read_csv('audita_glosa_auditar_item_dc362200_73728acb.csv', chunksize = cs,sep=";", encoding='latin-1', dtype = {'Cd. Paciente': str, 
                                                                                                                         'Número da Carteira':str
                                                                                                                        })


loop = tqdm(desc="Progresso: ", total = total)

a=1

for data in df:
    if a == 1:
        data.to_excel('output.xlsx', index=False)
        del(data)
        loop.update(cs)
        a=a+1
        continue
    else:
        data.to_excel('output.xlsx', index=False, header=False)
        del(data)
        loop.update(cs)
        continue
        
        

    
    
# 16-minutos
    

#datatoexcel = pd.ExcelWriter('formatado.xlsx')

#df.to_excel(datatoexcel)

#datatoexcel.save()

#print('Dados salvos com sucesso.')





#df.to_excel('arquivo_formatado.xlsx', index=False)

