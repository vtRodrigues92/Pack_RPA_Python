import openpyxl as xl
from openpyxl import Workbook, load_workbook
from openpyxl.utils.cell import get_column_letter
from automagica import ExcelReadCell


wb = xl.load_workbook('output.xlsx')
sheet = wb.worksheets[0]

number_of_rows = sheet.max_row


r=2
value = ExcelReadCell(path='output.xlsx', cell="AS"+str(r), sheet=None)

key_replace = {"=":""}


while r <= number_of_rows:
    for key in key_replace.keys():
        print(value)
        if value == key:
            newCellValue = key_replace.get(key)
            
    





#column.replace("=", "")
  
# 
#for i in column:
#    for k in range(number_of_rows): 
#        cellValue = i 
#        for key in replacementTextKeyPairs.keys(): 
#                if cellValue == key: 
#                    newCellValue = replacementTextKeyPairs.get(key) 
#                    sheet[get_column_letter(i+1)+str(k+1)] = str(newCellValue)
                

#wb.save('test.xlsx')
