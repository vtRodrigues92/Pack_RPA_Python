import tabula
import pandas as pd
from IPython.display import display
import openpyxl as xl

lista_tabelas = tabula.read_pdf("10009167_Atalaia_Vigência 01.01.2022.pdf", pages="all")
print(len(lista_tabelas))


a=1

for tabela in lista_tabelas:
    if a == 1:
        with pd.ExcelWriter (path='output.xlsx', engine='openpyxl') as writer:
            tabela.to_excel(writer, index=False)
        a=a+1
    else:
        wb = xl.load_workbook('output.xlsx', read_only=False)
        sheet = wb.worksheets[0]
        max_row = sheet.max_row
        with pd.ExcelWriter (path='output.xlsx', mode='a', if_sheet_exists="overlay", engine='openpyxl') as writer:
            tabela.to_excel(writer, index=False, header=None, startrow=max_row)
