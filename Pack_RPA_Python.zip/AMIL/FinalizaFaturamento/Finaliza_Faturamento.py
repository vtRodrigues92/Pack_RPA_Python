# -*- coding: utf-8 -*-
from selenium import webdriver
from automagica import Wait
import openpyxl as xl
from automagica import ExcelReadCell
from automagica import ExcelWriteCell
import os
import ctypes
from tqdm import tqdm
from tkinter import messagebox, filedialog
from tkinter import *
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager

#_____________________________________________________________________________________________________________________#

print()
print('#################################################################')
print('########### AUTOMATIZAÇÃO DE PROCESSOS RECEBÍVEIS ###############')
print('#################################################################')
print('##################### SEJA BEM VINDO ############################')
print('#################################################################')
print('################ CRIADO POR VICTOR RODRIGUES ####################')
print('#################################################################')
print('Versão = 0.2.2')
print('Ambiente: Produção\n')

Wait(1)
print('Você está usando um programa automatizado que finaliza o faturamento postado no site da AMIL!')

#Ocultando a janela raiz do tkinter
root = Tk()
root.withdraw()

# Mensagem de iformação
Wait(1)
messagebox.showinfo("FinalizaFaturamento", "Antes de continuar, selecione a pasta que será utilizada pelo robô.")

# Selecionando pasta
Wait(1)
folder = filedialog.askdirectory()
print('Pasta selecionada: '+folder)

#Procurando arquivo excel
Wait(1)
encontrar_excel = os.listdir(folder)
for fileExcel in encontrar_excel:
    if fileExcel.endswith(".xlsx"):
        print('Excel encontrado: '+ fileExcel)
        break


#Lendo Excel
PathExcel = folder + "\\" + fileExcel
wb = xl.load_workbook(PathExcel, read_only=False)
sheet = wb.worksheets[0]
max_row = sheet.max_row
registros = sheet.max_row -1
rows=sheet.max_row -1

# Mostrando qntd de registros
Wait(1)
print(str(registros) + ' registros encontrados no arquivo excel\n')

# Definindo opções para o browser
chrome_options = webdriver.ChromeOptions() 
chrome_options.add_argument("--disable-gpu")
chrome_options.add_experimental_option('excludeSwitches', ['enable-logging'])

# Opção para executar o prgrama em primeiro ou segundo plano
escolha = int(input('Deseja que o programa seja executado em primeiro[1] ou segundo[2] plano? --> '))
print()

Wait(1)
if escolha == 1:
    print('O programa será executado em primeiro plano.\n')
else:
    print('O programa será executado em segundo plano.\n')
    chrome_options.add_argument("--headless")


Wait(1)
print()
print('Identificando a versão do seu browser(Google Chrome) para o correto funcionamento. . .')

# Chamando o browser com as opções e maximizando a janela
browser = webdriver.Chrome(ChromeDriverManager().install(),chrome_options=chrome_options)
print()
print('Versão localizada e configurada com sucesso.\n')
print('Iniciando o programa. . .')
browser.get(r"https://credenciado.amil.com.br/login")
browser.maximize_window()
Wait(10)

# Variaveis globais
r=2
rlogin=2

plogin = ExcelReadCell(path=PathExcel, cell="B"+str(rlogin), sheet=None)

def login_site (browser=browser):
    # Variavel global
    global r
    global rlogin
    global login
    global plogin
    
    # Xpath dos campos login
    campo_login = '//*[@id="login-usuario"]'
    campo_senha = '//*[@id="login-senha"]'
    btn_entrar = '/html/body/as-main-app/as-login-container/div[1]/div/as-login/div[2]/form/fieldset/button'
        
    
    #fechando Walktour e popups
    try:
        if browser.find_elements_by_xpath('//*[@id="onetrust-close-btn-container"]/button'):
            browser.find_element_by_xpath('//*[@id="onetrust-close-btn-container"]/button').click()
        if browser.find_elements_by_xpath('//*[@id="finalizar-walktour"]'):
            browser.find_element_by_xpath('//*[@id="finalizar-walktour"]').click()
    except:
        pass
    
    login = ExcelReadCell(path=PathExcel, cell="B"+str(r), sheet=None)
    senha = ExcelReadCell(path=PathExcel, cell="C"+str(r), sheet=None)
    
    # Tentativa de inserir login e senha
    a=1
    while a < 11:
        try:
            browser.find_element_by_xpath(campo_login).send_keys(login)
            browser.find_element_by_xpath(campo_senha).send_keys(senha)
            browser.find_element_by_xpath(btn_entrar).click()
            Wait(10)
            # Verificar se acesso está inválido
            e=1
            while True:
                if browser.find_elements_by_xpath('/html/body/as-main-app/as-login-container/div[1]/div/as-login/div[2]/form/fieldset/as-message/div/p'):
                    acesso_invalido = browser.find_element_by_xpath('/html/body/as-main-app/as-login-container/div[1]/div/as-login/div[2]/form/fieldset/as-message/div/p')
                    it_acesso_invalido = browser.execute_script("return arguments[0].innerText;", acesso_invalido)
                    ExcelWriteCell(PathExcel, cell="E"+str(r), sheet= None, write_value=it_acesso_invalido)
                    loop.update(1)
                    browser.find_element_by_xpath(campo_login).clear()
                    browser.find_element_by_xpath(campo_senha).clear()
                    r=r+1
                    rlogin=rlogin+1
                    login_site()
                else:
                    break
            break
        except:
            browser.refresh()
            Wait(10)
            a=a+1
            
login_site()

# Iniciando a barra de progresso
print()
print()
print('\nIniciando a iteração, por favor aguarde. . .\n')

loop = tqdm(desc="Progresso: ", total = registros)

def finaliza_faturamento(browser=browser):
    
    b=1
    try:
        while b < 11:
            try:
                if browser.find_elements_by_link_text("Faturamento"):
                    browser.find_element_by_link_text("Faturamento").click()
                    Wait(5)
                    break
                else:
                    browser.refresh()
                    b=b+1
            except:
                browser.refresh()
                b=b+1
                
        # Verificando se tem WalkTour
        if browser.find_elements_by_xpath('//*[@id="finalizar-walktour"]'):
            browser.find_element_by_xpath('//*[@id="finalizar-walktour"]').click()
            Wait(2)
        
        # Clicando na busca Protocolo
        browser.find_element_by_xpath('//*[@id="contas-medicas"]/as-consulta/section/div/div/dl[2]/dd[2]').click()
        Wait(2)
        
        if browser.find_elements_by_xpath('//*[@id="finalizar-walktour"]'):
            browser.find_element_by_xpath('//*[@id="finalizar-walktour"]').click()
            Wait(2)
        
        c=1
        while c < 11:
            try:
                browser.find_element_by_xpath('//*[@id="identificador"]').click()
                browser.find_element_by_xpath('//*[@id="identificador"]').clear()
                break
            
            except:
                Wait(3)
                c=c+1
        
        # Definindo o protocolo no Excel e inserindo no campo de consulta e clicando em Pesquisar
        protocolo = ExcelReadCell(PathExcel, "D"+str(r), sheet=None)
        browser.find_element_by_xpath('//*[@id="identificador"]').send_keys(protocolo)
        browser.find_element_by_xpath('//*[@id="contas-medicas"]/as-consulta/section/div/div/as-consulta-protocolo/form/button').click()
        Wait(5) 
        
        # Enquanto encontrar mensagem de erro, att a pagina.
        #while True:
            #if browser.find_elements_by_xpath('//*[@id="contas-medicas"]/as-consulta/section/div/div/as-consulta-protocolo/form/div[4]/as-consulta-protocolo-status-processamento/as-message/div'):
                #browser.refresh()
                #Wait(10)
                #finaliza_faturamento()
            #else:
               #break
                
                
        # Validação se encontrou o protoclo e se o protocolo consultado é o mesmo do encontrado
        c=1
        while c < 11:
            try:
                if browser.find_elements_by_xpath('//*[@id="contas-medicas"]/as-consulta/section/div/as-resultado-protocolo/div[1]/div/div/div/table/tbody/tr/td[4]'):
                    r_protocolo = browser.find_element_by_xpath('//*[@id="contas-medicas"]/as-consulta/section/div/as-resultado-protocolo/div[1]/div/div/div/table/tbody/tr/td[4]')
                    it_protocolo = browser.execute_script("return arguments[0].innerText;", r_protocolo)
                elif browser.find_elements_by_xpath('//*[@id="contas-medicas"]/as-consulta/section/div/div[2]/p'):
                    nencontrado = browser.find_element_by_xpath('//*[@id="contas-medicas"]/as-consulta/section/div/div[2]/p')
                    it_nencontrado = browser.execute_script("return arguments[0].innerText;", nencontrado)
                    ExcelWriteCell(PathExcel, cell="E"+str(r), sheet= None, write_value=it_nencontrado)
                    return
                else:
                    pass
                
                if it_protocolo == str(protocolo):
                    break
                else:
                    browser.refresh()
                    Wait(10)
                    if browser.find_elements_by_xpath('//*[@id="login-usuario"]'):
                        login_site()
                    else:
                        finaliza_faturamento()
                    c=c+1
            except:
                Wait(3)
                c=c+1
        
                        
        # Ações de acordo com o status do protocolo
        status_protocolo = browser.find_element_by_xpath('//*[@id="contas-medicas"]/as-consulta/section/div/as-resultado-protocolo/div[1]/div/div/div/table/tbody/tr/td[7]/as-tooltip/dl/dd')
        it_status_protocolo = browser.execute_script("return arguments[0].innerText;", status_protocolo)
        
        # Tente: Se o status do protocolo for Em análise, escreve no Excel
        try:
            
            if it_status_protocolo == " Em análise" or it_status_protocolo == "Em análise":
                ExcelWriteCell(PathExcel, cell="E"+str(r), sheet= None, write_value="Protocolo já está confirmado")
                return
            # Se o status do protocolo for Liberado para pagamento, escreve no Excel
            if it_status_protocolo == " Liberado para pagamento" or it_status_protocolo == "Liberado para pagamento":
                ExcelWriteCell(PathExcel, cell="E"+str(r), sheet= None, write_value="Protocolo está confirmado e liberado para pagamento")
                return            
            # Se o status do protocolo for Processado com glosa de bloqueio, escreve no Excel
            if it_status_protocolo == " Processado com glosa de bloqueio" or it_status_protocolo == "Processado com glosa de bloqueio":
                ExcelWriteCell(PathExcel, cell="E"+str(r), sheet= None, write_value="Processado com glosa de bloqueio")
                return
            ## Se o status do protocolo for Aguardando finalização do faturamento, segue o processo de finalização
            if it_status_protocolo == " Aguardando finalização de faturamento" or it_status_protocolo == " Processado com glosa" or it_status_protocolo == "Aguardando finalização de faturamento" or it_status_protocolo == "Processado com glosa":
                # Clicando em opções
                browser.find_element_by_xpath('//*[@id="list-button-acoes"]').click()
                # Clicando em Finalizar faturamento
                browser.find_element_by_xpath('//*[@id="show-list"]/div/div[2]/li/button').click()
                Wait(3)
                
                # Tente clicar
                try:
                    browser.find_element_by_xpath('//*[@id="content"]/section/div[1]/as-card-protocolos/div/div[1]/form/button[2]').click()
                except:
                    browser.find_element_by_xpath('//*[@id="content"]/section/div[1]/as-card-protocolos/div/div[1]/form/button[1]').click()
                    
                d=1
                while d < 11:
                    try:
                        if browser.find_elements_by_xpath('//*[@id="content"]/section/div[1]/as-card-protocolos/div/as-message/div/p'):
                            resultado = browser.find_element_by_xpath('//*[@id="content"]/section/div[1]/as-card-protocolos/div/as-message/div/p')
                            it_resultado = browser.execute_script("return arguments[0].innerText;", resultado)
                            ExcelWriteCell(PathExcel, cell="E"+str(r), sheet= None, write_value=it_resultado)
                            browser.find_element_by_xpath('//*[@id="content"]/section/div[2]/button').click()
                            break
                            
                        else:
                            Wait(3)
                            d=d+1
                    except:
                        Wait(3)
                        d=d+1
            else:
                ExcelWriteCell(PathExcel, cell="E"+str(r), sheet= None, write_value="Nenhum resultado encontrado ")
                            
                            
            
        except:
            browser.refresh()
            Wait(10)
            if browser.find_elements_by_xpath('//*[@id="login-usuario"]'):
                login_site()
            else:
                pass
    except:
        browser.refresh()
        Wait(10)
        if browser.find_elements_by_xpath('//*[@id="login-usuario"]'):
                login_site()
        else:
            finaliza_faturamento()

finaliza_faturamento()


def repetir(browser=browser):
    global r
    global login
    global rlogin
    while registros <= max_row: 
        # Somando 1 registro na barra de progresso
        loop.update(1)
        # Definindo a proxima linha de login
        rlogin=rlogin+1
        plogin = ExcelReadCell(path=PathExcel, cell="B"+str(rlogin), sheet=None)       
    
        # Verifica se a linha do login atual é igual a proxima linha de login
        # Se for igual, volta pra função finaliza_faturamento
        # Se não, faz logoff e ativa a função login e depois a função finaliza_faturamento
        try:
            if login == plogin:
                r=r+1
                finaliza_faturamento()
                continue
            if plogin == None:
                break
            else:
                r=r+1
                browser.find_element_by_xpath('/html/body/as-main-app/as-contas-medicas/as-base-layout/as-header-container/header/div/div/as-menu-usuario/div/div[1]').click()
                Wait(1)
                browser.find_element_by_xpath('/html/body/as-main-app/as-contas-medicas/as-base-layout/as-header-container/header/div/div/as-menu-usuario/div/div[2]/form/button').click()
                Wait(3)
                login_site()
                finaliza_faturamento()

        except:
            browser.refresh()
            Wait(10)
            if browser.find_elements_by_xpath('//*[@id="login-usuario"]'):
                login_site()
            else:
                finaliza_faturamento()

repetir()


loop.close()
browser.close()
ctypes.windll.user32.MessageBoxW(0, "Programa finalizado com sucesso. Verifique o arquivo Excel.", "FinalizaFaturamento", 1)
os.system('cd '+ folder)
os.system('start .')

    