from multiprocessing import Event
import tkinter as tk
from tkinter import LEFT, PhotoImage, ttk
from automagica import Wait
from webdriver_manager.chrome import ChromeDriverManager


contador = 0
contacts = []
prestador = 1
carteira = 2
beneficiario = 3

class Tela:
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options

    def __init__(self, master):
               
        #Definindo a tela master
        self.nossaTela = master
        
        # Label Frame (contorno) Entrada de dados
        self.label_frame = tk.LabelFrame(self.nossaTela, text = "Entrada de dados")

        #Entrada de dados Login
        self.label_login = tk.Label(self.label_frame, text="Login: ", font=('verdana', 10)).grid(row=0, column=0)
        self.entrada_login = ttk.Entry(self.label_frame)
        self.entrada_login.grid(row=0, column=1, padx=10, pady=10)

        #Entrada de dados Autorização
        self.label_autorizacao = tk.Label(self.label_frame, text="Autorização: ", font=('verdana', 10)).grid(row=0, column=2)
        self.entrada_autorizacao = ttk.Entry(self.label_frame)
        self.entrada_autorizacao.grid (row=0, column=3, padx=10, pady=0)

        # Botão Consultar
        self.btn_enviar = ttk.Button(self.label_frame,text="Consultar")
        self.btn_enviar.grid(row=0, column=4, padx=5, pady=10)
        self.btn_enviar.bind("<Button-1>", self.consultar)    

        # Definindo icone do botão download
        self.icon_dowload = PhotoImage(file = r"C:\Users\f14815964700\Downloads\RPA\AMIL\ConsultaAutorização\icon_download.png")
        self.icon_dowload2 = self.icon_dowload.subsample(20,20)

        # Botão Download
        self.btn_download = tk.Button(self.label_frame, text = " Exportar resultado", image=self.icon_dowload2, compound=LEFT)
        self.btn_download.grid(row = 0, column=5, padx=13, pady=0)
        self.btn_download.bind("<Button-1>", self.exportar)



        # Posição do Label Frame (contorno)
        self.label_frame.grid(row=0, column=3)

        # Caixa com Saida de dados
        #self.list_box = tk.Listbox(height =40,width =150)
        #self.list_box.grid(row=6, column=3, padx=10, pady=10)
        
        self.columns = ('PRESTADOR','CARTEIRA','BENEFICIÁRIO','SIT_CARTEIRA','AUTORIZAÇÃO','SIT_AUTORIZAÇÃO','PROCEDIMENTO','DESCRIÇÃO','SIT_PROCEDIMENTO')
        
        self.tree = ttk.Treeview(janelaRaiz, columns=self.columns, show='headings')
        
        self.tree.heading('PRESTADOR', text='PRESTADOR')
        self.tree.column('PRESTADOR', width=100, anchor=tk.CENTER)
        
        self.tree.heading('CARTEIRA', text='CARTEIRA')
        self.tree.column('CARTEIRA', width=100, anchor=tk.CENTER)
        
        self.tree.heading('BENEFICIÁRIO', text='BENEFICIÁRIO')
        self.tree.column('BENEFICIÁRIO', width=100, anchor=tk.CENTER)
        
        self.tree.heading('SIT_CARTEIRA', text='SIT_CARTEIRA')
        self.tree.column('SIT_CARTEIRA', width=100, anchor=tk.CENTER)
        
        self.tree.heading('AUTORIZAÇÃO', text='AUTORIZAÇÃO')
        self.tree.column('AUTORIZAÇÃO', width=100, anchor=tk.CENTER)
        
        self.tree.heading('SIT_AUTORIZAÇÃO', text='SIT_AUTORIZAÇÃO')
        self.tree.column('SIT_AUTORIZAÇÃO', width=100, anchor=tk.CENTER)
        
        self.tree.heading('PROCEDIMENTO', text='PROCEDIMENTO')
        self.tree.column('PROCEDIMENTO', width=100, anchor=tk.CENTER)
        
        self.tree.heading('DESCRIÇÃO', text='DESCRIÇÃO')
        self.tree.column('DESCRIÇÃO', width=200, anchor=tk.CENTER)
                
        self.tree.heading('SIT_PROCEDIMENTO', text='SIT_PROCEDIMENTO')
        self.tree.column('SIT_PROCEDIMENTO', width=100, anchor=tk.CENTER)
        
            
        self.tree.grid(row=1, column=3, ipady=200 ,ipadx=200 ,sticky='nsew')
    
    
                        
    
        
    def consultar(self, event):
        global contador
        global contacts
        global prestador
        
        self.login = str(self.entrada_login.get())
        self.autorizacao = str(self.entrada_autorizacao.get())
        print(self.login)
        print(self.autorizacao) 
        
        
        self.columns = ('PRESTADOR','CARTEIRA','BENEFICIÁRIO','SIT_CARTEIRA','AUTORIZAÇÃO','SIT_AUTORIZAÇÃO','PROCEDIMENTO','DESCRIÇÃO','SIT_PROCEDIMENTO')
        
        self.tree = ttk.Treeview(janelaRaiz, columns=self.columns, show='headings')
        
        self.tree.heading('PRESTADOR', text='PRESTADOR')
        self.tree.column('PRESTADOR', width=100, anchor=tk.CENTER)
        
        self.tree.heading('CARTEIRA', text='CARTEIRA')
        self.tree.column('CARTEIRA', width=100, anchor=tk.CENTER)
        
        self.tree.heading('BENEFICIÁRIO', text='BENEFICIÁRIO')
        self.tree.column('BENEFICIÁRIO', width=100, anchor=tk.CENTER)
        
        self.tree.heading('SIT_CARTEIRA', text='SIT_CARTEIRA')
        self.tree.column('SIT_CARTEIRA', width=100, anchor=tk.CENTER)
        
        self.tree.heading('AUTORIZAÇÃO', text='AUTORIZAÇÃO')
        self.tree.column('AUTORIZAÇÃO', width=100, anchor=tk.CENTER)
        
        self.tree.heading('SIT_AUTORIZAÇÃO', text='SIT_AUTORIZAÇÃO')
        self.tree.column('SIT_AUTORIZAÇÃO', width=100, anchor=tk.CENTER)
        
        self.tree.heading('PROCEDIMENTO', text='PROCEDIMENTO')
        self.tree.column('PROCEDIMENTO', width=100, anchor=tk.CENTER)
        
        self.tree.heading('DESCRIÇÃO', text='DESCRIÇÃO')
        self.tree.column('DESCRIÇÃO', width=200, anchor=tk.CENTER)
                
        self.tree.heading('SIT_PROCEDIMENTO', text='SIT_PROCEDIMENTO')
        self.tree.column('SIT_PROCEDIMENTO', width=100, anchor=tk.CENTER)      
        
        
        self.buscar_dados()
        
        
               
        self.campo_prestador = self.text_prestador[11:]
        self.carteira = self.text_carteira[22:]
        self.beneficiario = self.text_beneficiario[5:]
        self.sit_carteira = 'aaaa'
        self.autorizacao = 'aaaa'
        self.sit_autorizacao = 'aaaaa'
        self.procedimento = 'aaaaa'
        self.descricao = 'aaaa'
        self.sit_procedimento = 'aaaa'
        
        
        for n in range(1,2):
           contacts.append((self.campo_prestador, self.carteira, self.beneficiario, self.sit_carteira, self.autorizacao, self.sit_autorizacao, self.procedimento, self.descricao, self.sit_procedimento))
        
        print(contacts)
        
        for contact in contacts:
            self.tree.insert('', 0, values=contact)
        
            
        self.tree.grid(row=1, column=3, ipady=200 ,ipadx=200 ,sticky='nsew')
        
        scrollbar = ttk.Scrollbar(janelaRaiz, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscroll=scrollbar.set)
        scrollbar.grid(row=1, column=4, sticky='ns')
            
            
    def buscar_dados(self):
        self.chrome_options = self.webdriver.ChromeOptions() 
        self.chrome_options.add_argument("--disable-gpu")
        self.chrome_options.add_experimental_option('excludeSwitches', ['enable-logging'])
        #self.chrome_options.add_argument("--headless")
        self.browser = self.webdriver.Chrome(ChromeDriverManager().install(),chrome_options=self.chrome_options)
        self.browser.get(r"https://credenciado.amil.com.br/login")
        self.browser.maximize_window()
        Wait(10)
        
        # Variavel global
        global r
        global rlogin
        global login
        global plogin
        
        # Xpath dos campos login
        campo_login = '//*[@id="login-usuario"]'
        campo_senha = '//*[@id="login-senha"]'
        btn_entrar = '/html/body/as-main-app/as-login-container/div[1]/div/as-login/div[2]/form/fieldset/button'
            
        
        #fechando Walktour e popups
        try:
            if self.browser.find_elements_by_xpath('//*[@id="onetrust-close-btn-container"]/button'):
                self.browser.find_element_by_xpath('//*[@id="onetrust-close-btn-container"]/button').click()
            if self.browser.find_elements_by_xpath('//*[@id="finalizar-walktour"]'):
                self.browser.find_element_by_xpath('//*[@id="finalizar-walktour"]').click()
        except:
            pass
        
        
        
        login = self.login
        senha = "DASA@2022"
        
        # Tentativa de inserir login e senha
        a=1
        while a < 11:
            try:
                self.browser.find_element_by_xpath(campo_login).send_keys(login)
                self.browser.find_element_by_xpath(campo_senha).send_keys(senha)
                self.browser.find_element_by_xpath(btn_entrar).click()
                Wait(10)
                # Verificar se acesso está inválido
                e=1
                while True:
                    if self.browser.find_elements_by_xpath('/html/body/as-main-app/as-login-container/div[1]/div/as-login/div[2]/form/fieldset/as-message/div/p'):
                        acesso_invalido = self.browser.find_element_by_xpath('/html/body/as-main-app/as-login-container/div[1]/div/as-login/div[2]/form/fieldset/as-message/div/p')
                        it_acesso_invalido = self.browser.execute_script("return arguments[0].innerText;", acesso_invalido)

                        self.browser.find_element_by_xpath(campo_login).clear()
                        self.browser.find_element_by_xpath(campo_senha).clear()
                        r=r+1
                        rlogin=rlogin+1
                        #login_site(self, browser)
                    else:
                        break
                break
            except:
                self.browser.refresh()
                Wait(10)
                a=a+1
        
        '''Clicando na opção autorização prévia'''
        b=1
        try:
            while b < 11:
                try:
                    if self.browser.find_elements_by_link_text("Autorização prévia"):
                        self.browser.find_element_by_link_text("Autorização prévia").click()
                        Wait(5)
                        break
                    else:
                        self.browser.refresh()
                        b=b+1
                except:
                    self.browser.refresh()
                    b=b+1
                    
            '''Verificando se tem WalkTour'''
            if self.browser.find_elements_by_xpath('//*[@id="finalizar-walktour"]'):
                self.browser.find_element_by_xpath('//*[@id="finalizar-walktour"]').click()
                Wait(2)
            
            '''Clicando na busca Protocolo'''
            self.browser.find_element_by_xpath('//*[@id="identificacao"]').click()
            self.browser.find_element_by_xpath('//*[@id="identificacao"]').clear()
            Wait(2)
            
            '''Inserindo autorização e pesquisando'''
            self.browser.find_element_by_xpath('//*[@id="identificacao"]').send_keys(self.autorizacao)
            self.browser.find_element_by_xpath('//*[@id="pedidos-autorizacao"]/as-consulta-pedidos-autorizacao/section/div[2]/div[1]/button').click()
        
            a=1
            while a < 5:
                if self.browser.find_elements_by_xpath('//*[@id="pedidos-autorizacao"]/as-consulta-pedidos-autorizacao/section/div[2]/div[2]/div[2]/table/tbody/tr/td[8]/button'):
                    self.browser.find_element_by_xpath('//*[@id="pedidos-autorizacao"]/as-consulta-pedidos-autorizacao/section/div[2]/div[2]/div[2]/table/tbody/tr/td[8]/button').click()
                    break
                else:
                    Wait(2)
                    a+=1
            
            Wait(10)
            
            '''Coletando informações'''
            self.prestador = self.browser.find_element_by_xpath('//*[@id="detalhes-autorizacao"]/menu-pedido/div[6]/ul[1]/li[1]')                                                               
            self.text_prestador = self.browser.execute_script("return arguments[0].innerText;", self.prestador)
            print(self.text_prestador[11:])
            
            self.carteira = self.browser.find_element_by_xpath('//*[@id="undefined"]/as-info-beneficiario/as-beneficiario-plano/section/div/div/ul[1]/li[2]')
            self.text_carteira = self.browser.execute_script("return arguments[0].innerText;", self.carteira)
            print(self.text_carteira[21:])
            
            self.beneficiario = self.browser.find_element_by_xpath('//*[@id="undefined"]/as-info-beneficiario/as-beneficiario-plano/section/div/div/ul[1]/li[1]')
            self.text_beneficiario = self.browser.execute_script("return arguments[0].innerText;", self.beneficiario)
            print(self.text_beneficiario[4:])
            
            self.sit_carteira = ''
            self.text_sit_carteira = ''
            self.autorizacao = ''
            self.text_autorizacao = ''
            self.sit_autorizacao = ''
            self.text_sit_autorizacao = ''
            self.procedimento = ''
            self.text_procedimento = ''
            self.descricao = ''
            self.text_descricao = ''
            self.sit_procedimento = ''
            self.text_sit_procedimento = ''
            
            
        except:
            pass
        
        
        '''# Lendo a quantidade de resultado
        linhas = len(browser.find_elements_by_xpath('//*[@id="pedidos-autorizacao"]/as-consulta-pedidos-autorizacao/section/div[2]/div[2]/div[2]/table/tbody/tr'))
        # percorrendo os resultados a fim de encontrar a autorização do procedimento
        for l in linhas:
            browser.find_element_by_xpath('//*[@id="pedidos-autorizacao"]/as-consulta-pedidos-autorizacao/section/div[2]/div[2]/div[2]/table/tbody/tr[{}]/td[8]/button').format(l).click()
            '''
    
        
        
        
        
        
        

    def exportar(self, event):
        pass

    



    
janelaRaiz = tk.Tk()
Tela(janelaRaiz)
janelaRaiz.mainloop()