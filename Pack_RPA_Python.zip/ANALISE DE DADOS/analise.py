#%%
import pandas as pd
import numpy as np
import plotly.offline as py
import plotly.graph_objs as go
import plotly.express as px
import seaborn as sns
import matplotlib.pyplot as plt


#%%
data = pd.read_csv('teste.csv', sep="|", encoding='latin-1')

# Convertendo string do valor total para float
data['Vl.Total.Exame'] = data['Vl.Total.Exame'].apply(lambda x: float(x.replace(".","").replace(",",".")))

# Agrupando e somando por 'codStatus'
df_agrupado = data.groupby('CodStatus').sum()

# "tabela dinamica" com status e valor do exame
df_dinamica = df_agrupado.loc[:,'Vl.Total.Exame']

#%%

df_classificado = df_dinamica.nlargest()

print(df_classificado)










#%%


#grafico = (df_agrupado.sort_values(by=['Vl.Total.Exame'],ascending=False))

#g7 = px.bar(data,
#            x = 'CodStatus',
#            y = 'Vl.Total.Exame',
#            title = 'Taxa de fertilidade por País(2020)',
#            color_discrete_sequence=["red"],
#            color='Vl.Total.Exame',
#            
#            )


#g7.show()



# %%
