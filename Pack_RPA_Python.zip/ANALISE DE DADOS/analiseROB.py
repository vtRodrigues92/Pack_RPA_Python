#%%
import pandas as pd
import numpy as np
import plotly.offline as py
import plotly.graph_objs as go
import plotly.express as px
import seaborn as sns
import matplotlib.pyplot as plt

#%%
rob2021 = '\\fs-smb-br-spo1.dasa.net\DP_CFGR\Faturamento\Faturamento RJ\MIDIA RJ\001-TROCA DE ARQUIVOS\Victor\AMIL\Estudo_ROB_21_22\esft111_AMILSP_ROB_JANFEV-2021_111534.csv'
df_rob2021 = pd.read_csv(rob2021,
                      sep="|", encoding='latin-1')
# %%
