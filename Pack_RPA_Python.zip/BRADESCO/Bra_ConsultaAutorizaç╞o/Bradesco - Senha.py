# -*- coding: utf-8 -*-

from selenium import webdriver
from automagica import Wait
import openpyxl as xl
from automagica import ExcelReadCell
from automagica import ExcelWriteCell
import os
import webbrowser
import ctypes



'''btn_cpf = '//*[@id="cpfRefPJ"]'
btn_cnpj = '//*[@id="cnpjRef"]'
btn_senha = '//*[@id="senhaRef"]'
btn_acessar = '//*[@id="btLoginReferenciado"]'
btn_campo_cartao = '//*[@id="dados_beneficiario_cartao"]'
btn_medico = '//*[@id="dadosMedicoSolicitante_profissionalSolicitante"]'
btn_conselho = '//*[@id="dadosMedicoSolicitante_numeroConselho"]'
btn_procedimento = '//*[@id="procedimento_txtCodigoDescricao"]'''

print('Olá usuário!')
Wait(1)
print('Você está usando o robô_Bradesco que consulta senha WEB!')
Wait(1)


def codigo():

    

    path_pasta = input('Insira o caminho do arquivo Excel ---> ')
    
    Wait(1)
    print('Executando programa....')


    encontrar_excel = os.listdir(path_pasta)
    for fileExcel in encontrar_excel:
        if fileExcel.endswith(".xlsx"):
            print(fileExcel)
            break

    PathExcel = path_pasta + "\\" + fileExcel
    wb = xl.load_workbook(PathExcel, read_only=False)
    sheet = wb.worksheets[0]
    codigo.max_row = sheet.max_row
    registros = sheet.max_row -1
    rows=sheet.max_row -1

    rowresult = 2
    r = 2
    '''rcnpj = 2
    rcpf = 2
    rsenha = 2
    id_cpf = ExcelReadCell(path=PathExcel, cell="G" + str(rcpf), sheet=None)
    id_cnpj = ExcelReadCell(path=PathExcel, cell="H" + str(rcnpj), sheet=None)
    id_senha = ExcelReadCell(path=PathExcel, cell="I" + str(rsenha), sheet=None)'''

    browser = webdriver.Chrome(path_pasta + "\\" + "chromedriver.exe")
    window_first = browser.window_handles[0]
    browser.get(r"https://wwws.bradescosaude.com.br/PCBS-GerenciadorPortal/td/loginReferenciado.do")

    def acessando_site():

        '''Wait(2)
        while True:
            if browser.find_elements_by_xpath(btn_cpf):
                browser.find_element_by_xpath(btn_cpf).click()
                browser.find_element_by_xpath(btn_cpf).send_keys(id_cpf)
                browser.find_element_by_xpath(btn_cnpj).send_keys(id_cnpj)
                browser.find_element_by_xpath(btn_senha).send_keys(id_senha)
                browser.find_element_by_xpath(btn_acessar).click()
                break   
            else:
                print('erro na linha 75')
                browser.close()'''

        print("Essa parte é com você!")
        input("Insira o login e senha no site e aperte enter...")
        
        Wait(5)

        try:
            while True:
                if browser.find_elements_by_xpath('//*[@id="modal2013011870"]/img[2]'):
                        browser.find_element_by_xpath('//*[@id="modal2013011870"]/img[2]').click()
                        browser.find_element_by_xpath('//*[@id="modal2013011867"]/img[2]').click()
                        browser.find_element_by_xpath('//*[@id="modal2013011843"]/img[2]').click()
                        browser.find_element_by_xpath('//*[@id="modal2013011950"]/img[2]').click()
                        browser.find_element_by_xpath('//*[@id="modal2013011877"]/img[2]').click()
                        break
                else:
                        browser.refresh()
                        Wait(5)
                        print('erro na linha 92')
        except:
            print('Xpath de avisos não encontrado')

        Wait(3)

        try:
            browser.find_element_by_xpath('//*[@id="menu_servico_1"]').click()
        except:
            browser.find_element_by_xpath('//*[@id="menu_servico_1"]').click()


        main_page = browser.current_window_handle

        for handle in browser.window_handles:
            if handle != main_page:
                next_page = handle

        browser.switch_to.window(next_page)

        browser.maximize_window()

        Wait(3)

        btn_SADT = '//*[@id="botoes_img"]/div[5]/img[1]'
        browser.find_element_by_xpath('//*[@id="comboReferenciado"]').click()
        browser.find_element_by_xpath('//*[@id="comboReferenciado"]').send_keys("0")
        browser.find_element_by_xpath('//*[@id="divfiltroReferenciado"]/table[2]/tbody/tr[3]/td/button/span').click()
        Wait(5)

        if browser.find_elements_by_xpath('/html/body/div[5]/div/div[2]/div/button'):
            browser.find_element_by_xpath('/html/body/div[5]/div/div[2]/div/button').click()
        
        Wait(3)
    acessando_site()

    print(registros, str("Registros encontrados."))
    print('Iniciando as consultas...')
    while r < codigo.max_row + 1:
        print(str("Consultando"), r -1, str("de"), registros, str("registros"))
        try:
            if browser.find_elements_by_xpath('//*[@id="botoes_img"]/div[1]/img[1]'):
                browser.find_element_by_xpath('//*[@id="botoes_img"]/div[1]/img[1]').click()
                carteira = ExcelReadCell(path=PathExcel, cell="C" + str(r), sheet=None)
                dt_ini = ExcelReadCell(path=PathExcel, cell="E" + str(r), sheet=None)
                dt_fim = ExcelReadCell(path=PathExcel, cell="F" + str(r), sheet=None)

                card_invalido = '//*[@id="msgErros"]/tbody/tr/td/li'
                resultado = '//*[@id="listaConsultaSolicitacaoVO"]/tbody/tr/td[8]/div'

                browser.find_element_by_xpath('//*[@id="periodoDe"]').click()
                browser.find_element_by_xpath('//*[@id="periodoDe"]').clear()
                browser.find_element_by_xpath('//*[@id="periodoDe"]').send_keys(dt_ini)
                browser.find_element_by_xpath('//*[@id="periodoAte"]').click()
                browser.find_element_by_xpath('//*[@id="periodoAte"]').clear()
                browser.find_element_by_xpath('//*[@id="periodoAte"]').send_keys(dt_fim)
                browser.find_element_by_xpath('//*[@id="txtCartao"]').send_keys(carteira)
                browser.find_element_by_xpath('//*[@id="btnConsultarSolicitacao"]/span').click()
                Wait(1)
                if browser.find_elements_by_xpath(card_invalido):
                    
                    ExcelWriteCell(path=PathExcel, cell="J" + str(r), sheet=None, write_value="Número do cartão inválido")
                    r = r + 1
                    ncnpj = ExcelReadCell(path=PathExcel, cell="G" + str(rcnpj), sheet=None)
                    cnpj_atual = ExcelReadCell(path=PathExcel, cell="G" + str(r), sheet=None)
                    if cnpj_atual == ncnpj:
                        rcnpj = rcnpj + 1
                        continue
                    elif r >= codigo.max_row + 1:
                        break
                    else:
                        rcpf=rcpf +1
                        rcnpj = rcnpj + 1
                        rsenha = rsenha +1
                        id_cpf = ExcelReadCell(path=PathExcel, cell="G" + str(rcpf), sheet=None)
                        id_cnpj = ExcelReadCell(path=PathExcel, cell="H" + str(rcnpj), sheet=None)
                        id_senha = ExcelReadCell(path=PathExcel, cell="I" + str(rsenha), sheet=None)
                        browser.close()
                        browser.switch_to_window(window_first)
                        browser.close()
                        browser = webdriver.Chrome(path_pasta + "\\" + "chromedriver.exe")
                        window_first = browser.window_handles[0]
                        browser.get(r"https://wwws.bradescosaude.com.br/PCBS-GerenciadorPortal/td/loginReferenciado.do")
                        acessando_site()

                else:
                    browser.find_element_by_xpath('//*[@id="btnConsultarSolicitacao"]/span').click()


                    if browser.find_elements_by_xpath(resultado):
                        

                        '''Lista solicitacoes'''
                        linhas = len(browser.find_elements_by_xpath('//*[@id="listaConsultaSolicitacaoVO"]/tbody/tr'))

                        for lsoli in range(1, linhas +1):
                            item = '//*[@id="listaConsultaSolicitacaoVO"]/tbody/tr[{}]/td[1]/input'.format(lsoli)
                                    
                            browser.find_element_by_xpath(item).click()
                            Wait(2)
                            browser.find_element_by_xpath('//*[@id="botoes_img"]/div[6]/img[1]').click()

                            '''Lista procedimentos'''
                            linhas2 = len(browser.find_elements_by_xpath('//*[@id="listProcedimentosSolicitacaoVO"]/tbody/tr'))

                            for lproce in range(1, linhas2 +1):
                                '''Variaveis'''
                                refe = browser.find_element_by_xpath('//*[@id="hospital"]/table/tbody/tr[2]/td[2]/span')
                                nome_refe = browser.find_element_by_xpath('//*[@id="hospital"]/table/tbody/tr[2]/td[4]/span')
                                solicitante = browser.find_element_by_xpath('//*[@id="discagem"]/table/tbody/tr[2]/td[4]/span')
                                cartao = browser.find_element_by_xpath('//*[@id="resultadoAnalise"]/table[1]/tbody/tr[3]/td[2]/span')
                                nome = browser.find_element_by_xpath('//*[@id="resultadoAnalise"]/table[1]/tbody/tr[3]/td[4]/span')
                                nguia = browser.find_element_by_xpath('//*[@id="resultadoAnalise"]/table[1]/tbody/tr[4]/td[2]/span')
                                rede = browser.find_element_by_xpath('//*[@id="resultadoAnalise"]/table[1]/tbody/tr[5]/td[2]/span')
                                tsolici = browser.find_element_by_xpath('//*[@id="resultadoAnalise"]/table[1]/tbody/tr[6]/td[2]/span')
                                result = browser.find_element_by_xpath('//*[@id="resultadoAnalise"]/table[1]/tbody/tr[6]/td[4]/span')
                                dt_soli = browser.find_element_by_xpath('/html/body/div[1]/div/div[5]/div/div/div/div[1]/div[1]/div/div/div[3]/table[1]/tbody/tr[3]/td[6]/span')

                                
                                if browser.find_elements_by_xpath('//*[@id="resultadoAnalise"]/table/tbody/tr[2]/td[4]/span'):
                                    datacan = browser.find_element_by_xpath('/html/body/div[1]/div/div[5]/div/div/div/div[1]/div[1]/div/div/div[3]/div/table/tbody/tr[2]/td[2]/span')
                                    motivocan = browser.find_element_by_xpath('//*[@id="resultadoAnalise"]/table/tbody/tr[2]/td[4]/span')
                                    descricaocan = browser.find_element_by_xpath('/html/body/div[1]/div/div[5]/div/div/div/div[1]/div[1]/div/div/div[3]/div/table/tbody/tr[3]/td[2]/span')
                                    inner_text_datacan = browser.execute_script("return arguments[0].innerText;", datacan)
                                    inner_text_motivocan = browser.execute_script("return arguments[0].innerText;", motivocan)
                                    inner_text_descricaocan = browser.execute_script("return arguments[0].innerText;", descricaocan)
                                    ExcelWriteCell(path=PathExcel, cell="U" + str(rowresult), sheet='Retorno_robo', write_value=inner_text_datacan)
                                    ExcelWriteCell(path=PathExcel, cell="T" + str(rowresult), sheet='Retorno_robo', write_value=inner_text_motivocan)
                                    ExcelWriteCell(path=PathExcel, cell="V" + str(rowresult), sheet='Retorno_robo', write_value=inner_text_descricaocan)
                                else:
                                    senha = browser.find_element_by_xpath('/html/body/div[1]/div/div[5]/div/div/div/div[1]/div[1]/div/div/div[3]/table[1]/tbody/tr[7]/td[2]/span')
                                    inner_text_senha = browser.execute_script("return arguments[0].innerText;", senha)

                                '''Texto das variaveis'''
                                inner_text_refe = browser.execute_script("return arguments[0].innerText;", refe)
                                inner_text_nome_refe = browser.execute_script("return arguments[0].innerText;", nome_refe)
                                inner_text_solicitante = browser.execute_script("return arguments[0].innerText;", solicitante)
                                inner_text_cartao = browser.execute_script("return arguments[0].innerText;", cartao)
                                inner_text_nome = browser.execute_script("return arguments[0].innerText;", nome)    
                                inner_text_nguia = browser.execute_script("return arguments[0].innerText;", nguia)
                                inner_text_rede = browser.execute_script("return arguments[0].innerText;", rede)
                                inner_text_tsolici = browser.execute_script("return arguments[0].innerText;", tsolici)
                                inner_text_result = browser.execute_script("return arguments[0].innerText;", result)    

                                inner_text_dt_soli = browser.execute_script("return arguments[0].innerText;", dt_soli)

                                '''Escrevendo no excel'''
                                ExcelWriteCell(path=PathExcel, cell="D" + str(rowresult), sheet='Retorno_robo', write_value=inner_text_refe)
                                ExcelWriteCell(path=PathExcel, cell="E" + str(rowresult), sheet='Retorno_robo', write_value=inner_text_nome_refe)
                                ExcelWriteCell(path=PathExcel, cell="F" + str(rowresult), sheet='Retorno_robo', write_value=inner_text_solicitante)
                                ExcelWriteCell(path=PathExcel, cell="G" + str(rowresult), sheet='Retorno_robo', write_value=inner_text_cartao)
                                ExcelWriteCell(path=PathExcel, cell="H" + str(rowresult), sheet='Retorno_robo', write_value=inner_text_nome)
                                ExcelWriteCell(path=PathExcel, cell="I" + str(rowresult), sheet='Retorno_robo', write_value=inner_text_nguia)
                                ExcelWriteCell(path=PathExcel, cell="J" + str(rowresult), sheet='Retorno_robo', write_value=inner_text_rede)
                                ExcelWriteCell(path=PathExcel, cell="K" + str(rowresult), sheet='Retorno_robo', write_value=inner_text_tsolici)
                                ExcelWriteCell(path=PathExcel, cell="M" + str(rowresult), sheet='Retorno_robo', write_value=inner_text_result)
                                ExcelWriteCell(path=PathExcel, cell="C" + str(rowresult), sheet='Retorno_robo', write_value=inner_text_dt_soli)
                                
                                if inner_text_result == 'Liberada':
                                    ExcelWriteCell(path=PathExcel, cell="L" + str(rowresult), sheet='Retorno_robo', write_value=inner_text_senha)
                                else:    
                                    ExcelWriteCell(path=PathExcel, cell="L" + str(rowresult), sheet='Retorno_robo', write_value=None)
                            
                                
                                '''Variaveis'''

                                xcod = '//*[@id="listProcedimentosSolicitacaoVO"]/tbody/tr[{}]/td[1]'.format(lproce)
                                xdescr = '//*[@id="listProcedimentosSolicitacaoVO"]/tbody/tr[{}]/td[2]'.format(lproce)
                                xorigem = '//*[@id="listProcedimentosSolicitacaoVO"]/tbody/tr[{}]/td[3]'.format(lproce)
                                xqtdsoli = '//*[@id="listProcedimentosSolicitacaoVO"]/tbody/tr[{}]/td[4]'.format(lproce)
                                xqtdaut = '//*[@id="listProcedimentosSolicitacaoVO"]/tbody/tr[{}]/td[5]'.format(lproce)
                                xstatus = '//*[@id="listProcedimentosSolicitacaoVO"]/tbody/tr[{}]/td[6]'.format(lproce)
                                                                
                                cod = browser.find_element_by_xpath(xcod)
                                descr = browser.find_element_by_xpath(xdescr)
                                origem = browser.find_element_by_xpath(xorigem)
                                qtdsoli = browser.find_element_by_xpath(xqtdsoli)
                                qtdaut = browser.find_element_by_xpath(xqtdaut)
                                status = browser.find_element_by_xpath(xstatus)

                                '''Texto das variaveis'''
                                inner_text_cod = browser.execute_script("return arguments[0].innerText;", cod)
                                inner_text_descr = browser.execute_script("return arguments[0].innerText;", descr)
                                inner_text_origem = browser.execute_script("return arguments[0].innerText;", origem)
                                inner_text_qtdsoli = browser.execute_script("return arguments[0].innerText;", qtdsoli)
                                inner_text_qtdaut = browser.execute_script("return arguments[0].innerText;", qtdaut)    
                                inner_text_status = browser.execute_script("return arguments[0].innerText;", status)

                                '''Escrevendo no excel'''
                                ExcelWriteCell(path=PathExcel, cell="N" + str(rowresult), sheet='Retorno_robo', write_value=inner_text_cod)
                                ExcelWriteCell(path=PathExcel, cell="O" + str(rowresult), sheet='Retorno_robo', write_value=inner_text_descr)
                                ExcelWriteCell(path=PathExcel, cell="P" + str(rowresult), sheet='Retorno_robo', write_value=inner_text_origem)
                                ExcelWriteCell(path=PathExcel, cell="Q" + str(rowresult), sheet='Retorno_robo', write_value=inner_text_qtdsoli)
                                ExcelWriteCell(path=PathExcel, cell="R" + str(rowresult), sheet='Retorno_robo', write_value=inner_text_qtdaut)
                                ExcelWriteCell(path=PathExcel, cell="S" + str(rowresult), sheet='Retorno_robo', write_value=inner_text_status)
                                rowresult = rowresult +1

                            if linhas == lsoli:
                                break
                                
                            else:
                                browser.find_element_by_xpath('//*[@id="botoes_img"]/div[1]/img[1]').click()
                                browser.find_element_by_xpath('//*[@id="txtCartao"]').send_keys(carteira)
                                browser.find_element_by_xpath('//*[@id="periodoDe"]').click()
                                browser.find_element_by_xpath('//*[@id="periodoDe"]').clear()
                                browser.find_element_by_xpath('//*[@id="periodoDe"]').send_keys(dt_ini)
                                browser.find_element_by_xpath('//*[@id="periodoAte"]').click()
                                browser.find_element_by_xpath('//*[@id="periodoAte"]').clear()
                                browser.find_element_by_xpath('//*[@id="periodoAte"]').send_keys(dt_fim)
                                Wait(1)
                                browser.find_element_by_xpath('//*[@id="btnConsultarSolicitacao"]/span').click()

                    else:
                        ExcelWriteCell(path=PathExcel, cell="J" + str(r), sheet=None, write_value="Não foram encontrados registros para o filtro informado!")
                        
                    while True:
                        r = r + 1
                        ncnpj = ExcelReadCell(path=PathExcel, cell="H" + str(rcnpj), sheet=None)
                        cnpj_atual = ExcelReadCell(path=PathExcel, cell="H" + str(r), sheet=None)
                        if cnpj_atual == ncnpj:
                            rcnpj = rcnpj + 1
                            break
                        elif r >= codigo.max_row + 1:
                            break
                        else:
                            print('Trocando login....')
                            rcpf=rcpf +1
                            rcnpj = rcnpj + 1
                            rsenha = rsenha +1
                            id_cpf = ExcelReadCell(path=PathExcel, cell="G" + str(rcpf), sheet=None)
                            id_cnpj = ExcelReadCell(path=PathExcel, cell="H" + str(rcnpj), sheet=None)
                            id_senha = ExcelReadCell(path=PathExcel, cell="I" + str(rsenha), sheet=None)
                            browser.close()
                            browser.switch_to_window(window_first)
                            browser.close()
                            browser = webdriver.Chrome(path_pasta + "\\" + "chromedriver.exe")
                            window_first = browser.window_handles[0]
                            browser.get(r"https://wwws.bradescosaude.com.br/PCBS-GerenciadorPortal/td/loginReferenciado.do")
                            acessando_site()

                            break
                    Wait(2)

            else:
                if browser.find_elements_by_xpath('//*[@id="formularioError"]/button/span'):
                    browser.find_element_by_xpath('//*[@id="formularioError"]/button/span').click()
                else:
                    browser.refresh()
                    Wait(10)
                    print('erro na linha 336')
                    continue

        except:
            browser.close()
            browser.switch_to_window(window_first)
            browser.close()
            browser = webdriver.Chrome(path_pasta + "\\" + "chromedriver.exe")
            window_first = browser.window_handles[0]
            browser.get(r"https://wwws.bradescosaude.com.br/PCBS-GerenciadorPortal/td/loginReferenciado.do")
            acessando_site()
            continue
    
    browser.close()
    browser.switch_to_window(window_first)
    browser.close()
    ctypes.windll.user32.MessageBoxW(0, "Consultas realizadas com sucesso!", "Robô diz:", 1)


codigo()
