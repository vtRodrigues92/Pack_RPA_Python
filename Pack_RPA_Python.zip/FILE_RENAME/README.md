# RenomeadorDeArquivos
Automação da tarefa "Renomear arquivo". Bastante funcional quando se precisa renomear um grande volume de arquivos.

Etapas:

1 - Selecionar a pasta que contenha os arquivos que serão renomeados;
2 - Inserir o nome do prefixo que será inserido;
3 - Inserir a extensão dos arquivos que serão renomeados.

Após inputar os valores, uma barra de progresso será exibido para acompanhamento da atividade de conversão.

Ao término da tarefa, uma caixa de mensagem será exibido informando que o processo foi concluído.

